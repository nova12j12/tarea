/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

int main() {
    std::cout << "Múltiplos de 3 entre 1 y 20: ";
    
    for (int i = 1; i <= 20; i++) {
        if (i % 3 == 0) {
            std::cout << i << " ";
        }
    }

    std::cout << std::endl;

    return 0;
}