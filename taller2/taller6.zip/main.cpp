/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>

int contarOvejas(std::vector<bool> ovejas) {
    int contador = 0;
    for (bool presente : ovejas) {
        if (presente) {
            contador++;
        }
    }
    return contador;
}

int main() {
    std::vector<bool> ovejas = {true, false, true, true, false, true, true, true, false, true,
                                true, false, true, true, true, true, true, true};

    int cantidadPresentes = contarOvejas(ovejas);

    std::cout << "Número de ovejas presentes: " << cantidadPresentes << std::endl;

    return 0;
}