/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

double elevarPotencia(double numero, int potencia) {
    double resultado = 1.0;
    for (int i = 0; i < potencia; i++) {
        resultado *= numero;
    }
    return resultado;
}

int main() {
    double numero;
    int potencia;

    std::cout << "Ingrese un número: ";
    std::cin >> numero;
    std::cout << "Ingrese la potencia: ";
    std::cin >> potencia;

    double resultado = elevarPotencia(numero, potencia);

    std::cout << numero << " elevado a la potencia " << potencia << " es " << resultado << std::endl;

    return 0;
}